//Mini Project: Random winner generator

//Users can input elements into an array and then select a random winner from that array and display it on the screen

var output = document.getElementById('output');
var output2 = document.getElementById('output2');
var enter = document.getElementById('enter');
var gen = document.getElementById('gen');

var input1 = document.getElementById('input1');

var array = [];

function addName(){
    if (input1.value=== null || input1.value === ""){
    alert("You must enter a valid name!");
    } else {
    var newLi = document.createElement('li');
    output.appendChild(newLi);
    newLi.innerHTML = input1.value;
    array.push(input1.value);
    input1.value = '';
    }
}

function randomWinner(){
    if (array.length === 0){
        alert('Enter some names and try again!');
    } else {
    output2.innerHTML = 'The random winner today is ' + array[Math.floor(Math.random() * array.length)]+'!!!';
    }
}


enter.addEventListener('click', addName);
gen.addEventListener('click', randomWinner);



















